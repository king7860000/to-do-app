function addTask() {
  const taskInput = document.getElementById("taskInput");
  const taskList = document.getElementById("taskList");

  if (taskInput.value.trim() === "") {
    alert("Please enter a task.");
    return;
  }

  const li = document.createElement("li");

  li.innerHTML = \`
    <span onclick="toggleTask(this)">${taskInput.value}</span>
    <button onclick="removeTask(this)">X</button>
  \`;

  taskList.appendChild(li);
  taskInput.value = "";
}

function toggleTask(span) {
  span.parentElement.classList.toggle("completed");
}

function removeTask(button) {
  button.parentElement.remove();
}